import { useEffect, useMemo, useState } from "react";
import { flushSync } from "react-dom";
import * as Dialog from "@radix-ui/react-dialog";
import { Clapperboard, Home, Play, Search, Settings, Tv, X } from "lucide-react";
import {
  allGenres,
  DEMO_CATALOG,
  findEpisode,
  findTitle,
  progressKey,
  sortQualities,
  titlesMatching,
  type Catalog,
  type Episode,
  type Title,
} from "@/lib/catalog";
import { loadRemoteCatalog } from "@/lib/fetch-catalog";
import {
  CATALOG_URL_KEY,
  continueList,
  loadProgress,
  loadVolume,
  saveProgress,
  saveVolume,
  type ProgressEntry,
} from "@/lib/progress";
import { Player, type Playback } from "@/components/player";

type Tab = "home" | "movies" | "series" | "search";

const TABS: { id: Tab; label: string; icon: typeof Home }[] = [
  { id: "home", label: "Home", icon: Home },
  { id: "movies", label: "Movies", icon: Clapperboard },
  { id: "series", label: "Series", icon: Tv },
  { id: "search", label: "Search", icon: Search },
];

function ratingLabel(value: number): string {
  return value.toFixed(1);
}

export function App() {
  const [tab, setTab] = useState<Tab>("home");
  const [catalog, setCatalog] = useState<Catalog>(DEMO_CATALOG);
  const [source, setSource] = useState<"sample" | "remote">("sample");
  const [catalogError, setCatalogError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [draftUrl, setDraftUrl] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [playback, setPlayback] = useState<Playback | null>(null);
  const [progress, setProgress] = useState<Record<string, ProgressEntry>>({});
  const [volume, setVolume] = useState(1);
  const [keyword, setKeyword] = useState("");
  const [genre, setGenre] = useState("");
  const [year, setYear] = useState("");
  const [minRating, setMinRating] = useState(0);

  useEffect(() => {
    setProgress(loadProgress());
    setVolume(loadVolume());
    const saved = localStorage.getItem(CATALOG_URL_KEY);
    if (saved) {
      setDraftUrl(saved);
      void connect(saved);
    }
    // Connect once on first visit if a catalog URL was saved.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (selectedId && !findTitle(catalog, selectedId)) setSelectedId(null);
  }, [catalog, selectedId]);

  async function connect(url: string) {
    setLoading(true);
    setCatalogError(null);
    try {
      const next = await loadRemoteCatalog({ data: { url } });
      setCatalog(next);
      setSource("remote");
      localStorage.setItem(CATALOG_URL_KEY, url);
      setDraftUrl(url);
      setSettingsOpen(false);
    } catch (error) {
      setCatalog(DEMO_CATALOG);
      setSource("sample");
      setCatalogError(error instanceof Error ? error.message : "Could not load that catalog.");
    } finally {
      setLoading(false);
    }
  }

  function useSample() {
    localStorage.removeItem(CATALOG_URL_KEY);
    setCatalog(DEMO_CATALOG);
    setSource("sample");
    setCatalogError(null);
    setDraftUrl("");
    setSettingsOpen(false);
  }

  function onVolume(next: number) {
    setVolume(next);
    saveVolume(next);
  }

  const selected = selectedId ? findTitle(catalog, selectedId) : undefined;
  const movies = catalog.items.filter((item) => item.type === "movie");
  const series = catalog.items.filter((item) => item.type === "series");
  const featured = movies[0] ?? catalog.items[0];
  const genres = allGenres(catalog.items);
  const results = titlesMatching(catalog.items, { keyword, genre, year, minRating });
  const resume = continueList(progress);

  function openTitle(id: string) {
    setSelectedId(id);
    setPlayback(null);
  }

  function playTitle(title: Title, episode?: Episode, startAt?: number) {
    const qualities = sortQualities(episode ? episode.qualities : title.qualities);
    if (qualities.length === 0) return;
    const key = progressKey(title.id, episode?.id);
    const stored = progress[key];
    const at = startAt ?? (stored && stored.seconds > 8 ? stored.seconds : 0);
    flushSync(() => {
      setPlayback({
        key,
        titleId: title.id,
        episodeId: episode?.id,
        title: title.title,
        subtitle: episode
          ? `Season ${title.seasons.find((season) => season.episodes.some((item) => item.id === episode.id))?.number ?? 1} · E${episode.number} · ${episode.title}`
          : undefined,
        poster: episode?.still ?? title.backdrop ?? title.poster,
        qualities,
        captions: episode ? episode.captions : title.captions,
        startAt: at,
      });
    });
    const video = document.querySelector("video");
    if (video instanceof HTMLVideoElement) void video.play().catch(() => undefined);
  }

  function nextEpisode(current: Playback): { label: string; start: () => void } | undefined {
    if (!current.episodeId) return undefined;
    const title = findTitle(catalog, current.titleId);
    if (!title) return undefined;
    const flat = title.seasons.flatMap((season) => season.episodes);
    const index = flat.findIndex((episode) => episode.id === current.episodeId);
    const upcoming = flat[index + 1];
    if (!upcoming) return undefined;
    return {
      label: upcoming.title,
      start: () => playTitle(title, upcoming, 0),
    };
  }

  function recordProgress(seconds: number, duration: number) {
    if (!playback || !duration) return;
    const title = findTitle(catalog, playback.titleId);
    const entry: ProgressEntry = {
      seconds,
      duration,
      updated: Date.now(),
      titleId: playback.titleId,
      episodeId: playback.episodeId,
      label: title?.title ?? playback.title,
      detail: playback.subtitle ?? (title ? String(title.year) : ""),
    };
    setProgress(saveProgress(playback.key, entry));
  }

  return (
    <div className="min-h-dvh overflow-x-hidden bg-bg text-fg">
      <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-line bg-bg/95 px-4 backdrop-blur-sm">
        <img src="/favicon.svg" alt="" className="size-9 rounded-lg" />
        <div className="min-w-0 leading-none">
          <p className="font-display text-lg tracking-widest">RABBIT</p>
          <p className="text-xs tracking-widest text-muted">PRODUCTIONS</p>
        </div>
        <p className="ml-auto hidden truncate text-sm text-muted sm:block">
          {source === "remote" ? catalog.name : "Sample shelf"}
        </p>
        <button
          type="button"
          onClick={() => setSettingsOpen(true)}
          className="tap flex size-11 items-center justify-center rounded-full transition-transform duration-150 ease-out active:scale-[0.96]"
          aria-label="Catalog settings"
        >
          <Settings className="size-5" />
        </button>
      </header>

      {catalogError ? (
        <p className="mx-4 mt-3 rounded-xl bg-surface px-4 py-3 text-sm text-fg shadow-card">
          {catalogError} Showing the sample shelf instead.
        </p>
      ) : null}
      {loading ? <p className="px-4 pt-3 text-sm text-muted">Loading catalog…</p> : null}

      <main className="pb-24">
        {selected ? (
          <Detail
            title={selected}
            progress={progress}
            onBack={() => setSelectedId(null)}
            onPlay={(episode, at) => playTitle(selected, episode, at)}
          />
        ) : tab === "home" && featured ? (
          <HomeView
            featured={featured}
            movies={movies}
            series={series}
            resume={resume}
            onOpen={openTitle}
            onPlay={playTitle}
          />
        ) : tab === "movies" ? (
          <Grid heading="Movies" items={movies} onOpen={openTitle} />
        ) : tab === "series" ? (
          <Grid heading="Series" items={series} onOpen={openTitle} />
        ) : (
          <SearchView
            genres={genres}
            keyword={keyword}
            genre={genre}
            year={year}
            minRating={minRating}
            results={results}
            onKeyword={setKeyword}
            onGenre={setGenre}
            onYear={setYear}
            onRating={setMinRating}
            onOpen={openTitle}
          />
        )}
      </main>

      {!playback ? (
        <nav className="pb-safe fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg/95 backdrop-blur-sm">
          <ul className="mx-auto flex max-w-lg">
            {TABS.map((item) => {
              const active = !selected && tab === item.id;
              const Icon = item.icon;
              return (
                <li key={item.id} className="flex-1">
                  <button
                    type="button"
                    aria-current={active ? "page" : undefined}
                    onClick={() => {
                      setSelectedId(null);
                      setTab(item.id);
                    }}
                    className={`relative flex h-16 w-full flex-col items-center justify-center gap-1 text-xs ${active ? "text-fg" : "text-muted"}`}
                  >
                    <span className={`absolute top-0 h-0.5 w-6 rounded-full bg-accent ${active ? "opacity-100" : "opacity-0"}`} />
                    <Icon className="size-5" />
                    {item.label}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>
      ) : null}

      {playback ? (
        <Player
          playback={playback}
          volume={volume}
          onVolume={onVolume}
          onProgress={recordProgress}
          onClose={() => setPlayback(null)}
          onNext={nextEpisode(playback)}
        />
      ) : null}

      <CatalogDialog
        open={settingsOpen}
        draft={draftUrl}
        loading={loading}
        source={source}
        error={catalogError}
        onDraft={setDraftUrl}
        onClose={() => setSettingsOpen(false)}
        onConnect={() => void connect(draftUrl.trim())}
        onSample={useSample}
      />
    </div>
  );
}

function HomeView({
  featured,
  movies,
  series,
  resume,
  onOpen,
  onPlay,
}: {
  featured: Title;
  movies: Title[];
  series: Title[];
  resume: ProgressEntry[];
  onOpen: (id: string) => void;
  onPlay: (title: Title) => void;
}) {
  return (
    <div>
      <section className="hero relative">
        <img
          src={featured.backdrop ?? featured.poster}
          alt=""
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/50 to-bg/10" />
        <div className="absolute inset-x-0 bottom-0 px-4 pb-5 sm:px-8">
          <p className="text-xs tracking-widest text-muted">FEATURED</p>
          <h1 className="mt-1 font-display text-4xl tracking-wide sm:text-6xl">{featured.title}</h1>
          <p className="mt-2 max-w-xl text-sm text-fg/90 sm:text-base">{featured.synopsis}</p>
          <p className="mt-2 text-sm text-muted">
            {featured.year} · {featured.genres.join(" · ")} · {ratingLabel(featured.rating)}
          </p>
          <div className="mt-4 flex gap-2">
            <button
              type="button"
              onClick={() => (featured.type === "movie" ? onPlay(featured) : onOpen(featured.id))}
              className="tap inline-flex h-12 items-center gap-2 rounded-full bg-accent px-5 text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
            >
              <Play className="size-5 translate-x-px" fill="currentColor" />
              {featured.type === "movie" ? "Play" : "Episodes"}
            </button>
            <button
              type="button"
              onClick={() => onOpen(featured.id)}
              className="tap inline-flex h-12 items-center rounded-full bg-surface px-5 shadow-card transition-transform duration-150 ease-out active:scale-[0.96]"
            >
              Details
            </button>
          </div>
        </div>
      </section>
      {resume.length > 0 ? (
        <section className="mt-6 px-4">
          <h2 className="font-display text-xl tracking-wide">Continue</h2>
          <div className="rail mt-3">
            {resume.map((entry) => (
              <button
                key={progressKey(entry.titleId, entry.episodeId)}
                type="button"
                onClick={() => onOpen(entry.titleId)}
                className="w-64 shrink-0 snap-start rounded-xl bg-surface p-3 text-left shadow-card"
              >
                <p className="truncate font-display tracking-wide">{entry.label}</p>
                <p className="truncate text-sm text-muted">{entry.detail}</p>
                <div className="mt-3 h-1 overflow-hidden rounded-full bg-line">
                  <div
                    className="h-full bg-accent"
                    style={{ width: `${Math.min(100, (entry.seconds / entry.duration) * 100)}%` }}
                  />
                </div>
              </button>
            ))}
          </div>
        </section>
      ) : null}
      <Rail title="Movies" items={movies} onOpen={onOpen} />
      <Rail title="Series" items={series} onOpen={onOpen} />
    </div>
  );
}

function Rail({ title, items, onOpen }: { title: string; items: Title[]; onOpen: (id: string) => void }) {
  if (items.length === 0) return null;
  return (
    <section className="mt-6 px-4">
      <h2 className="font-display text-xl tracking-wide">{title}</h2>
      <div className="rail mt-3">
        {items.map((item) => (
          <Tile key={item.id} item={item} onOpen={onOpen} />
        ))}
      </div>
    </section>
  );
}

function Tile({ item, onOpen }: { item: Title; onOpen: (id: string) => void }) {
  return (
    <button
      type="button"
      onClick={() => onOpen(item.id)}
      className="w-36 shrink-0 snap-start text-left sm:w-44"
    >
      <img
        src={item.poster}
        alt=""
        className="aspect-[2/3] w-full rounded-xl object-cover shadow-card outline outline-1 -outline-offset-1 outline-fg/10 transition-shadow duration-150 hover:shadow-card-hover"
      />
      <p className="mt-2 truncate font-display tracking-wide">{item.title}</p>
      <p className="text-sm text-muted">
        {item.year} · {ratingLabel(item.rating)}
      </p>
    </button>
  );
}

function Grid({ heading, items, onOpen }: { heading: string; items: Title[]; onOpen: (id: string) => void }) {
  return (
    <section className="px-4 pt-5">
      <h1 className="font-display text-3xl tracking-wide">{heading}</h1>
      {items.length === 0 ? (
        <p className="mt-6 text-muted">Nothing in this shelf yet. Connect a catalog from the settings mark.</p>
      ) : (
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {items.map((item) => (
            <Tile key={item.id} item={item} onOpen={onOpen} />
          ))}
        </div>
      )}
    </section>
  );
}

function Detail({
  title,
  progress,
  onBack,
  onPlay,
}: {
  title: Title;
  progress: Record<string, ProgressEntry>;
  onBack: () => void;
  onPlay: (episode?: Episode, startAt?: number) => void;
}) {
  const [seasonIndex, setSeasonIndex] = useState(0);
  const season = title.seasons[seasonIndex] ?? title.seasons[0];
  const first = season?.episodes[0];
  const movieKey = progressKey(title.id);
  const movieProgress = progress[movieKey];
  const resumeEpisode = season?.episodes.find((episode) => {
    const entry = progress[progressKey(title.id, episode.id)];
    return entry && entry.seconds > 8 && entry.seconds < entry.duration - 12;
  });

  return (
    <article>
      <div className="relative h-72 sm:h-96">
        <img src={title.backdrop ?? title.poster} alt="" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/40 to-bg/20" />
        <button
          type="button"
          onClick={onBack}
          className="tap absolute top-3 left-3 flex size-11 items-center justify-center rounded-full bg-surface shadow-card transition-transform duration-150 ease-out active:scale-[0.96]"
          aria-label="Back"
        >
          <X className="size-5" />
        </button>
      </div>
      <div className="-mt-16 px-4 sm:px-8">
        <h1 className="font-display text-4xl tracking-wide">{title.title}</h1>
        <p className="mt-2 text-sm text-muted">
          {title.year}
          {title.runtime ? ` · ${title.runtime} min` : ""} · {title.genres.join(" · ")} · {ratingLabel(title.rating)}
        </p>
        <p className="mt-3 max-w-2xl text-base">{title.synopsis}</p>
        <div className="mt-4">
          {title.type === "movie" ? (
            <button
              type="button"
              onClick={() => onPlay(undefined, movieProgress && movieProgress.seconds > 8 ? movieProgress.seconds : 0)}
              className="tap inline-flex h-12 items-center gap-2 rounded-full bg-accent px-5 text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
            >
              <Play className="size-5 translate-x-px" fill="currentColor" />
              {movieProgress && movieProgress.seconds > 8 ? "Resume" : "Play"}
            </button>
          ) : first ? (
            <button
              type="button"
              onClick={() => onPlay(resumeEpisode ?? first)}
              className="tap inline-flex h-12 items-center gap-2 rounded-full bg-accent px-5 text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
            >
              <Play className="size-5 translate-x-px" fill="currentColor" />
              {resumeEpisode ? `Resume E${resumeEpisode.number}` : `Play E${first.number}`}
            </button>
          ) : null}
        </div>
        {title.type === "series" && title.seasons.length > 1 ? (
          <div className="rail mt-6">
            {title.seasons.map((item, index) => (
              <button
                key={item.number}
                type="button"
                onClick={() => setSeasonIndex(index)}
                className={`h-11 shrink-0 rounded-full px-4 text-sm ${index === seasonIndex ? "bg-accent text-fg" : "bg-surface text-muted"}`}
              >
                Season {item.number}
              </button>
            ))}
          </div>
        ) : null}
        {season ? (
          <ul className="mt-4 divide-y divide-line border-t border-line">
            {season.episodes.map((episode) => {
              const entry = progress[progressKey(title.id, episode.id)];
              const ratio = entry && entry.duration ? Math.min(1, entry.seconds / entry.duration) : 0;
              return (
                <li key={episode.id}>
                  <button
                    type="button"
                    onClick={() => onPlay(episode, entry && entry.seconds > 8 ? entry.seconds : 0)}
                    className="flex w-full gap-3 py-3 text-left"
                  >
                    <img
                      src={episode.still ?? title.poster}
                      alt=""
                      className="h-16 w-28 shrink-0 rounded-lg object-cover shadow-card"
                    />
                    <span className="min-w-0 flex-1">
                      <span className="block font-display tracking-wide">
                        {episode.number}. {episode.title}
                      </span>
                      <span className="mt-1 block text-sm text-muted">{episode.synopsis}</span>
                      {ratio > 0 ? (
                        <span className="mt-2 block h-1 overflow-hidden rounded-full bg-line">
                          <span className="block h-full bg-accent" style={{ width: `${ratio * 100}%` }} />
                        </span>
                      ) : null}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        ) : null}
      </div>
    </article>
  );
}

function SearchView({
  genres,
  keyword,
  genre,
  year,
  minRating,
  results,
  onKeyword,
  onGenre,
  onYear,
  onRating,
  onOpen,
}: {
  genres: string[];
  keyword: string;
  genre: string;
  year: string;
  minRating: number;
  results: Title[];
  onKeyword: (value: string) => void;
  onGenre: (value: string) => void;
  onYear: (value: string) => void;
  onRating: (value: number) => void;
  onOpen: (id: string) => void;
}) {
  return (
    <section className="px-4 pt-5">
      <h1 className="font-display text-3xl tracking-wide">Search</h1>
      <label className="mt-4 block">
        <span className="text-sm text-muted">Keywords</span>
        <input
          value={keyword}
          onChange={(event) => onKeyword(event.target.value)}
          placeholder="Title, plot, episode"
          className="mt-1 h-12 w-full rounded-xl bg-surface px-4 text-fg shadow-card outline-none placeholder:text-muted"
        />
      </label>
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <label>
          <span className="text-sm text-muted">Year</span>
          <input
            inputMode="numeric"
            value={year}
            onChange={(event) => onYear(event.target.value.replace(/[^\d]/g, "").slice(0, 4))}
            placeholder="Any"
            className="mt-1 h-12 w-full rounded-xl bg-surface px-4 text-fg shadow-card outline-none placeholder:text-muted"
          />
        </label>
        <label>
          <span className="flex justify-between text-sm text-muted">
            Minimum rating
            <span className="tabular-nums text-fg">{minRating.toFixed(1)}</span>
          </span>
          <span className="mt-1 flex h-12 items-center rounded-xl bg-surface px-4 shadow-card">
            <input
              className="slider"
              type="range"
              min={0}
              max={10}
              step={0.1}
              value={minRating}
              aria-label="Minimum rating"
              onChange={(event) => onRating(Number(event.target.value))}
            />
          </span>
        </label>
      </div>
      <div className="rail mt-4">
        <FilterChip active={genre === ""} onClick={() => onGenre("")}>
          All genres
        </FilterChip>
        {genres.map((item) => (
          <FilterChip key={item} active={genre === item} onClick={() => onGenre(item)}>
            {item}
          </FilterChip>
        ))}
      </div>
      {results.length === 0 ? (
        <p className="mt-8 text-muted">No titles match that filter.</p>
      ) : (
        <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {results.map((item) => (
            <Tile key={item.id} item={item} onOpen={onOpen} />
          ))}
        </div>
      )}
    </section>
  );
}

function FilterChip({ active, onClick, children }: { active: boolean; onClick: () => void; children: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`h-11 shrink-0 snap-start rounded-full px-4 text-sm ${active ? "bg-accent text-fg" : "bg-surface text-muted shadow-card"}`}
    >
      {children}
    </button>
  );
}

function CatalogDialog({
  open,
  draft,
  loading,
  source,
  error,
  onDraft,
  onClose,
  onConnect,
  onSample,
}: {
  open: boolean;
  draft: string;
  loading: boolean;
  source: "sample" | "remote";
  error: string | null;
  onDraft: (value: string) => void;
  onClose: () => void;
  onConnect: () => void;
  onSample: () => void;
}) {
  const example = useMemo(
    () => `{
  "name": "My shelf",
  "items": [{
    "id": "film-1",
    "type": "movie",
    "title": "Title",
    "year": 2024,
    "genres": ["Drama"],
    "rating": 7.5,
    "poster": "https://your.server/poster.jpg",
    "qualities": [
      { "label": "1080p", "height": 1080, "src": "https://your.server/film-1080.mp4" },
      { "label": "720p", "height": 720, "src": "https://your.server/film-720.mp4" }
    ],
    "captions": [
      { "label": "English", "lang": "en", "src": "https://your.server/film.vtt" }
    ]
  }]
}`,
    [],
  );

  return (
    <Dialog.Root open={open} onOpenChange={(next) => { if (!next) onClose(); }}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-bg/80" />
        <Dialog.Content className="fixed inset-x-3 top-16 z-40 max-h-[80dvh] overflow-y-auto rounded-2xl bg-surface p-5 shadow-card sm:inset-x-auto sm:left-1/2 sm:w-[32rem] sm:-translate-x-1/2">
          <div className="flex items-start justify-between gap-3">
            <Dialog.Title className="font-display text-2xl tracking-wide">Your catalog</Dialog.Title>
            <Dialog.Close className="flex size-11 items-center justify-center rounded-full" aria-label="Close">
              <X className="size-5" />
            </Dialog.Close>
          </div>
          <Dialog.Description className="mt-2 text-sm text-muted">
            Point this at a JSON file on your server. Movies and episodes need direct video URLs. The highest quality plays first. A full example is at /catalog.example.json.
          </Dialog.Description>
          <label className="mt-4 block text-sm text-muted">
            Catalog URL
            <input
              value={draft}
              onChange={(event) => onDraft(event.target.value)}
              placeholder="https://your.server/catalog.json"
              className="mt-1 h-12 w-full rounded-xl bg-bg px-4 text-fg shadow-card outline-none placeholder:text-muted"
            />
          </label>
          {error ? <p className="mt-3 text-sm text-accent">{error}</p> : null}
          <p className="mt-3 text-sm text-muted">
            {source === "remote" ? "Connected to your server." : "Using the built-in sample shelf."}
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <button
              type="button"
              disabled={loading || draft.trim().length < 8}
              onClick={onConnect}
              className="tap h-11 rounded-full bg-accent px-5 text-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-50"
            >
              {loading ? "Connecting…" : "Connect"}
            </button>
            <button
              type="button"
              onClick={onSample}
              className="tap h-11 rounded-full bg-bg px-5 shadow-card transition-transform duration-150 ease-out active:scale-[0.96]"
            >
              Use sample shelf
            </button>
          </div>
          <details className="mt-5 text-sm">
            <summary className="cursor-pointer text-muted">Catalog shape</summary>
            <pre className="mt-3 overflow-x-auto rounded-xl bg-bg p-3 text-xs leading-relaxed text-fg">{example}</pre>
          </details>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
