import { useEffect, useRef, useState, type KeyboardEvent as ReactKey } from "react";
import { Captions, Gauge, Maximize, Pause, Play, Volume2, VolumeX, X } from "lucide-react";
import type { Caption, Stream } from "@/lib/catalog";

export type Playback = {
  key: string;
  titleId: string;
  episodeId?: string;
  title: string;
  subtitle?: string;
  poster?: string;
  qualities: Stream[];
  captions: Caption[];
  startAt: number;
};

type PlayerProps = {
  playback: Playback;
  volume: number;
  onVolume: (volume: number) => void;
  onProgress: (seconds: number, duration: number) => void;
  onClose: () => void;
  onNext?: { label: string; start: () => void };
};

function clock(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
  const whole = Math.floor(seconds);
  const hours = Math.floor(whole / 3600);
  const minutes = Math.floor((whole % 3600) / 60);
  const remain = whole % 60;
  const sec = String(remain).padStart(2, "0");
  if (hours > 0) return `${hours}:${String(minutes).padStart(2, "0")}:${sec}`;
  return `${minutes}:${sec}`;
}

export function Player({ playback, volume, onVolume, onProgress, onClose, onNext }: PlayerProps) {
  const stageRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const savedAt = useRef<number | null>(null);
  const lastReport = useRef(0);
  const [qualityIndex, setQualityIndex] = useState(0);
  const [captionIndex, setCaptionIndex] = useState(-1);
  const [menu, setMenu] = useState<"captions" | "quality" | null>(null);
  const [time, setTime] = useState(playback.startAt);
  const [duration, setDuration] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);
  const [hot, setHot] = useState(true);
  const [fs, setFs] = useState(false);
  const hideTimer = useRef(0);

  const stream = playback.qualities[qualityIndex] ?? playback.qualities[0];

  useEffect(() => {
    setQualityIndex(0);
    setCaptionIndex(-1);
    setReady(false);
    setFailed(false);
    setTime(playback.startAt);
    setMenu(null);
  }, [playback.key, playback.startAt]);

  useEffect(() => {
    const node = stageRef.current;
    node?.focus();
    const enter = node?.requestFullscreen?.();
    void enter?.catch(() => undefined);
    const onFs = () => setFs(document.fullscreenElement === node);
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, [playback.key]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    video.volume = volume;
    video.muted = volume === 0;
  }, [volume, stream?.src]);

  function applyCaptions() {
    const video = videoRef.current;
    if (!video) return;
    for (let index = 0; index < video.textTracks.length; index += 1) {
      video.textTracks[index]!.mode = index === captionIndex ? "showing" : "disabled";
    }
  }

  useEffect(() => {
    applyCaptions();
    // Tracks attach after the source loads; re-apply when the choice changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [captionIndex, stream?.src]);

  function poke() {
    setHot(true);
    window.clearTimeout(hideTimer.current);
    hideTimer.current = window.setTimeout(() => {
      if (videoRef.current && !videoRef.current.paused) setHot(false);
    }, 2800);
  }

  function toggle() {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) void video.play();
    else video.pause();
    poke();
  }

  function chooseQuality(index: number) {
    const video = videoRef.current;
    savedAt.current = video?.currentTime ?? time;
    setQualityIndex(index);
    setReady(false);
    setFailed(false);
    setMenu(null);
    poke();
  }

  function onLoaded() {
    const video = videoRef.current;
    if (!video) return;
    setDuration(video.duration || 0);
    const resume = savedAt.current ?? playback.startAt;
    if (resume > 1 && Math.abs(video.currentTime - resume) > 1) {
      video.currentTime = resume;
    }
    savedAt.current = null;
    applyCaptions();
    setReady(true);
    void video.play().catch(() => setPlaying(false));
  }

  async function toggleFullscreen() {
    const node = stageRef.current;
    if (!node) return;
    if (document.fullscreenElement) await document.exitFullscreen();
    else await node.requestFullscreen();
  }

  function onKeyDown(event: ReactKey<HTMLDivElement>) {
    const video = videoRef.current;
    if (!video) return;
    if (event.key === " " || event.key === "k") {
      event.preventDefault();
      toggle();
    } else if (event.key === "ArrowRight") {
      video.currentTime = Math.min(video.duration || 0, video.currentTime + 10);
    } else if (event.key === "ArrowLeft") {
      video.currentTime = Math.max(0, video.currentTime - 10);
    } else if (event.key === "f") {
      void toggleFullscreen();
    } else if (event.key === "m") {
      onVolume(volume === 0 ? 1 : 0);
    } else if (event.key === "Escape" && !document.fullscreenElement) {
      onClose();
    }
    poke();
  }

  if (!stream) return null;

  const showChrome = hot || !playing || menu !== null || failed;

  return (
    <div
      ref={stageRef}
      tabIndex={0}
      onKeyDown={onKeyDown}
      onPointerMove={poke}
      onPointerDown={poke}
      className="fixed inset-0 z-50 flex flex-col bg-bg text-fg outline-none"
    >
      <video
        ref={videoRef}
        key={stream.src}
        src={stream.src}
        className="h-full w-full bg-bg object-contain"
        poster={playback.poster}
        playsInline
        onLoadedMetadata={onLoaded}
        onPlay={() => setPlaying(true)}
        onPause={() => {
          setPlaying(false);
          setHot(true);
          const video = videoRef.current;
          if (video) onProgress(video.currentTime, video.duration || 0);
        }}
        onTimeUpdate={() => {
          const video = videoRef.current;
          if (!video) return;
          setTime(video.currentTime);
          if (video.currentTime - lastReport.current > 5) {
            lastReport.current = video.currentTime;
            onProgress(video.currentTime, video.duration || 0);
          }
        }}
        onEnded={() => {
          const video = videoRef.current;
          if (video) onProgress(video.currentTime, video.duration || 0);
          setPlaying(false);
          setHot(true);
        }}
        onError={() => setFailed(true)}
        onClick={toggle}
      >
        {playback.captions.map((caption) => (
          <track
            key={`${caption.lang}-${caption.src}`}
            kind="subtitles"
            src={caption.src}
            srcLang={caption.lang}
            label={caption.label}
          />
        ))}
      </video>

      {!ready && !failed ? (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="spin" role="status" aria-label="Loading video" />
        </div>
      ) : null}

      {failed ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 px-6 text-center">
          <p className="max-w-sm text-base">This stream did not load. Try another quality, or check the file URL in your catalog.</p>
          {playback.qualities.length > 1 ? (
            <div className="flex flex-wrap justify-center gap-2">
              {playback.qualities.map((item, index) => (
                <button
                  key={item.src}
                  type="button"
                  className="tap h-11 rounded-full bg-surface px-4 shadow-card transition-transform duration-150 ease-out active:scale-[0.96]"
                  onClick={() => chooseQuality(index)}
                >
                  {item.label}
                </button>
              ))}
            </div>
          ) : null}
        </div>
      ) : null}

      {!playing && ready && !failed ? (
        <button
          type="button"
          aria-label="Play"
          onClick={toggle}
          className="tap absolute top-1/2 left-1/2 flex size-16 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-accent text-fg transition-transform duration-150 ease-out active:scale-[0.96]"
        >
          <Play className="size-7 translate-x-px" fill="currentColor" />
        </button>
      ) : null}

      <div
        className={`absolute inset-x-0 top-0 flex items-start justify-between gap-3 bg-gradient-to-b from-bg via-bg/80 to-transparent px-3 pt-3 pb-10 transition-opacity duration-200 ${showChrome ? "opacity-100" : "pointer-events-none opacity-0"}`}
      >
        <button
          type="button"
          onClick={onClose}
          className="tap flex size-11 items-center justify-center rounded-full bg-surface shadow-card transition-transform duration-150 ease-out active:scale-[0.96]"
          aria-label="Close player"
        >
          <X className="size-5" />
        </button>
        <div className="min-w-0 pt-2 text-right">
          <p className="truncate font-display text-lg tracking-wide">{playback.title}</p>
          {playback.subtitle ? <p className="truncate text-sm text-muted">{playback.subtitle}</p> : null}
        </div>
      </div>

      <div
        className={`absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg via-bg/85 to-transparent px-3 pt-10 pb-3 transition-opacity duration-200 sm:px-5 ${showChrome ? "opacity-100" : "pointer-events-none opacity-0"}`}
      >
        <label className="flex h-11 items-center">
          <span className="sr-only">Seek</span>
          <input
            className="slider"
            type="range"
            min={0}
            max={duration || 0}
            step={0.1}
            value={Math.min(time, duration || 0)}
            aria-label="Seek"
            onChange={(event) => {
              const next = Number(event.currentTarget.value);
              setTime(next);
              if (videoRef.current) videoRef.current.currentTime = next;
            }}
          />
        </label>
        <div className="flex items-center gap-1 sm:gap-2">
          <button
            type="button"
            onClick={toggle}
            className="tap flex size-11 items-center justify-center rounded-full transition-transform duration-150 ease-out active:scale-[0.96]"
            aria-label={playing ? "Pause" : "Play"}
          >
            {playing ? <Pause className="size-5" fill="currentColor" /> : <Play className="size-5 translate-x-px" fill="currentColor" />}
          </button>
          <span className="w-24 shrink-0 text-sm tabular-nums text-muted">
            {clock(time)} / {clock(duration)}
          </span>
          <div className="ml-auto flex items-center gap-1">
            <div className="relative">
              <button
                type="button"
                aria-expanded={menu === "captions"}
                aria-label="Captions"
                onClick={() => setMenu((current) => (current === "captions" ? null : "captions"))}
                className="tap flex size-11 items-center justify-center rounded-full transition-transform duration-150 ease-out active:scale-[0.96]"
              >
                <Captions className="size-5" />
              </button>
              {menu === "captions" ? (
                <div className="absolute right-0 bottom-12 z-10 min-w-40 rounded-xl bg-raised p-1 shadow-card">
                  <MenuButton active={captionIndex < 0} onClick={() => { setCaptionIndex(-1); setMenu(null); }}>
                    Off
                  </MenuButton>
                  {playback.captions.map((caption, index) => (
                    <MenuButton
                      key={`${caption.lang}-${caption.src}`}
                      active={captionIndex === index}
                      onClick={() => {
                        setCaptionIndex(index);
                        setMenu(null);
                      }}
                    >
                      {caption.label}
                    </MenuButton>
                  ))}
                  {playback.captions.length === 0 ? (
                    <p className="px-3 py-2 text-sm text-muted">No captions in this file.</p>
                  ) : null}
                </div>
              ) : null}
            </div>
            <div className="relative">
              <button
                type="button"
                aria-expanded={menu === "quality"}
                aria-label="Stream quality"
                onClick={() => setMenu((current) => (current === "quality" ? null : "quality"))}
                className="tap flex h-11 items-center gap-1 rounded-full px-2 text-sm transition-transform duration-150 ease-out active:scale-[0.96]"
              >
                <Gauge className="size-5" />
                <span>{stream.label}</span>
              </button>
              {menu === "quality" ? (
                <div className="absolute right-0 bottom-12 z-10 min-w-36 rounded-xl bg-raised p-1 shadow-card">
                  {playback.qualities.map((item, index) => (
                    <MenuButton key={item.src} active={index === qualityIndex} onClick={() => chooseQuality(index)}>
                      {index === 0 ? `${item.label} · max` : item.label}
                    </MenuButton>
                  ))}
                </div>
              ) : null}
            </div>
            <label className="hidden h-11 w-28 items-center gap-2 sm:flex">
              <span className="sr-only">Volume</span>
              {volume === 0 ? <VolumeX className="size-5 shrink-0" /> : <Volume2 className="size-5 shrink-0" />}
              <input
                className="slider"
                type="range"
                min={0}
                max={1}
                step={0.01}
                value={volume}
                aria-label="Volume"
                onChange={(event) => onVolume(Number(event.currentTarget.value))}
              />
            </label>
            <button
              type="button"
              onClick={() => void toggleFullscreen()}
              className="tap flex size-11 items-center justify-center rounded-full transition-transform duration-150 ease-out active:scale-[0.96]"
              aria-label={fs ? "Exit full screen" : "Full screen"}
            >
              <Maximize className="size-5" />
            </button>
          </div>
        </div>
        <label className="mt-1 flex h-11 items-center gap-3 sm:hidden">
          {volume === 0 ? <VolumeX className="size-5 shrink-0" /> : <Volume2 className="size-5 shrink-0" />}
          <span className="sr-only">Volume</span>
          <input
            className="slider"
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={volume}
            aria-label="Volume"
            onChange={(event) => onVolume(Number(event.currentTarget.value))}
          />
        </label>
        {onNext ? (
          <div className="flex justify-end pb-1">
            <button
              type="button"
              onClick={onNext.start}
              className="tap h-11 rounded-full bg-surface px-4 text-sm shadow-card transition-transform duration-150 ease-out active:scale-[0.96]"
            >
              Next · {onNext.label}
            </button>
          </div>
        ) : null}
      </div>
    </div>
  );
}

function MenuButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex h-11 w-full items-center rounded-lg px-3 text-left text-sm ${active ? "bg-surface text-fg" : "text-muted"}`}
    >
      {children}
    </button>
  );
}
