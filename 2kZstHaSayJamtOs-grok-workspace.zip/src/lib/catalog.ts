export type Stream = {
  label: string;
  src: string;
  height?: number;
};

export type Caption = {
  label: string;
  lang: string;
  src: string;
};

export type Episode = {
  id: string;
  number: number;
  title: string;
  synopsis: string;
  runtime?: number;
  still?: string;
  captions: Caption[];
  qualities: Stream[];
};

export type Season = {
  number: number;
  episodes: Episode[];
};

export type Title = {
  id: string;
  type: "movie" | "series";
  title: string;
  year: number;
  genres: string[];
  rating: number;
  runtime?: number;
  synopsis: string;
  poster: string;
  backdrop?: string;
  captions: Caption[];
  qualities: Stream[];
  seasons: Season[];
};

export type Catalog = {
  name: string;
  items: Title[];
};

const SAMPLE_CAPTION: Caption[] = [
  { label: "English", lang: "en", src: "/captions/en.vtt" },
];

export const DEMO_CATALOG: Catalog = {
  name: "Sample shelf",
  items: [
    {
      id: "big-buck-bunny",
      type: "movie",
      title: "Big Buck Bunny",
      year: 2008,
      genres: ["Animation", "Comedy", "Family"],
      rating: 8.2,
      runtime: 10,
      synopsis:
        "A gentle giant of a rabbit has had enough of three bullying rodents. Open film from the Blender Foundation, on the sample shelf so you can try the player before connecting your catalog.",
      poster: "/posters/bunny.jpg",
      backdrop: "/posters/bunny-wide.jpg",
      captions: SAMPLE_CAPTION,
      qualities: [
        {
          label: "1080p",
          height: 1080,
          src: "https://upload.wikimedia.org/wikipedia/commons/transcoded/c/c0/Big_Buck_Bunny_4K.webm/Big_Buck_Bunny_4K.webm.1080p.vp9.webm",
        },
        {
          label: "720p",
          height: 720,
          src: "https://archive.org/download/BigBuckBunny_124/Content/big_buck_bunny_720p_surround.mp4",
        },
        {
          label: "480p",
          height: 480,
          src: "https://upload.wikimedia.org/wikipedia/commons/transcoded/c/c0/Big_Buck_Bunny_4K.webm/Big_Buck_Bunny_4K.webm.480p.vp9.webm",
        },
        {
          label: "360p",
          height: 360,
          src: "https://upload.wikimedia.org/wikipedia/commons/transcoded/c/c0/Big_Buck_Bunny_4K.webm/Big_Buck_Bunny_4K.webm.360p.vp9.webm",
        },
      ],
      seasons: [],
    },
    {
      id: "sintel",
      type: "movie",
      title: "Sintel",
      year: 2010,
      genres: ["Fantasy", "Adventure", "Drama"],
      rating: 7.6,
      runtime: 15,
      synopsis:
        "A young woman follows the trail of a lost dragon through snow and steel. Open film from the Blender Foundation, included on the sample shelf.",
      poster: "/posters/sintel.jpg",
      backdrop: "/posters/sintel.jpg",
      captions: SAMPLE_CAPTION,
      qualities: [
        {
          label: "2K",
          height: 1080,
          src: "https://archive.org/download/Sintel/sintel-2048-stereo.mp4",
        },
        {
          label: "512 kbps",
          height: 480,
          src: "https://archive.org/download/Sintel/sintel-2048-stereo_512kb.mp4",
        },
      ],
      seasons: [],
    },
    {
      id: "tears-of-steel",
      type: "movie",
      title: "Tears of Steel",
      year: 2012,
      genres: ["Sci-Fi", "Action"],
      rating: 7.1,
      runtime: 12,
      synopsis:
        "In a ruined city, a crew tries to pull a warrior back from the machines. Open film from the Blender Foundation, included on the sample shelf.",
      poster: "/posters/steel.jpg",
      backdrop: "/posters/steel.jpg",
      captions: SAMPLE_CAPTION,
      qualities: [
        {
          label: "1080p",
          height: 1080,
          src: "https://archive.org/download/Tears-of-Steel/tears_of_steel_1080p.mp4",
        },
        {
          label: "720p",
          height: 720,
          src: "https://archive.org/download/Tears-of-Steel/tears_of_steel_720p.mp4",
        },
      ],
      seasons: [],
    },
    {
      id: "elephants-dream",
      type: "movie",
      title: "Elephants Dream",
      year: 2006,
      genres: ["Sci-Fi", "Experimental"],
      rating: 6.4,
      runtime: 11,
      synopsis:
        "Two people wander a living machine that may only exist in one of their heads. Open film from the Blender Foundation, included on the sample shelf.",
      poster: "/posters/dream.jpg",
      backdrop: "/posters/dream.jpg",
      captions: SAMPLE_CAPTION,
      qualities: [
        {
          label: "HD",
          height: 1080,
          src: "https://archive.org/download/ElephantsDream/ed_hd.mp4",
        },
        {
          label: "1024",
          height: 576,
          src: "https://archive.org/download/ElephantsDream/ed_1024.mp4",
        },
        {
          label: "512 kbps",
          height: 480,
          src: "https://archive.org/download/ElephantsDream/ed_1024_512kb.mp4",
        },
      ],
      seasons: [],
    },
    {
      id: "caminandes",
      type: "series",
      title: "Caminandes",
      year: 2013,
      genres: ["Animation", "Comedy", "Short"],
      rating: 7.8,
      synopsis:
        "A llama, a desert, and three short open films from the Blender Foundation. Pick an episode and it starts at the highest quality in the file.",
      poster: "/posters/reels.jpg",
      backdrop: "/posters/reels.jpg",
      captions: [],
      qualities: [],
      seasons: [
        {
          number: 1,
          episodes: [
            {
              id: "cam-1",
              number: 1,
              title: "Llama Drama",
              synopsis: "The first short. Open film from the Blender Foundation.",
              runtime: 2,
              still: "/stills/escape.jpg",
              captions: SAMPLE_CAPTION,
              qualities: [
                {
                  label: "1080p",
                  height: 1080,
                  src: "https://archive.org/download/Caminandes1LlamaDrama/01_llama_drama_1080p.mp4",
                },
              ],
            },
            {
              id: "cam-2",
              number: 2,
              title: "Gran Dillama",
              synopsis: "The second short. Open film from the Blender Foundation.",
              runtime: 3,
              still: "/stills/joyride.jpg",
              captions: SAMPLE_CAPTION,
              qualities: [
                {
                  label: "1080p",
                  height: 1080,
                  src: "https://archive.org/download/Caminandes2GranDillama/02_gran_dillama_1080p.mp4",
                },
              ],
            },
            {
              id: "cam-3",
              number: 3,
              title: "Llamigos",
              synopsis: "The third short. Open film from the Blender Foundation.",
              runtime: 3,
              still: "/stills/blaze.jpg",
              captions: SAMPLE_CAPTION,
              qualities: [
                {
                  label: "1080p",
                  height: 1080,
                  src: "https://archive.org/download/CaminandesLlamigos/Caminandes_%20Llamigos-1080p.mp4",
                },
              ],
            },
          ],
        },
      ],
    },
  ],
};

export function sortQualities(qualities: Stream[]): Stream[] {
  return [...qualities].sort((a, b) => qualityRank(b) - qualityRank(a));
}

function qualityRank(stream: Stream): number {
  if (typeof stream.height === "number") return stream.height;
  const match = stream.label.match(/(\d{3,4})/);
  return match ? Number(match[1]) : 0;
}

export function progressKey(titleId: string, episodeId?: string): string {
  return episodeId ? `${titleId}:${episodeId}` : titleId;
}

export function findTitle(catalog: Catalog, id: string): Title | undefined {
  return catalog.items.find((item) => item.id === id);
}

export function findEpisode(title: Title, episodeId: string): Episode | undefined {
  for (const season of title.seasons) {
    const episode = season.episodes.find((item) => item.id === episodeId);
    if (episode) return episode;
  }
  return undefined;
}

export type SearchQuery = {
  keyword: string;
  genre: string;
  year: string;
  minRating: number;
};

export function titlesMatching(items: Title[], query: SearchQuery): Title[] {
  const keyword = query.keyword.trim().toLowerCase();
  const year = query.year.trim();
  return items.filter((item) => {
    if (query.genre && !item.genres.some((genre) => genre.toLowerCase() === query.genre.toLowerCase())) {
      return false;
    }
    if (year && String(item.year) !== year) return false;
    if (item.rating < query.minRating) return false;
    if (!keyword) return true;
    const episodeText = item.seasons
      .flatMap((season) => season.episodes.map((episode) => `${episode.title} ${episode.synopsis}`))
      .join(" ");
    const haystack = `${item.title} ${item.synopsis} ${item.genres.join(" ")} ${episodeText}`.toLowerCase();
    return haystack.includes(keyword);
  });
}

export function allGenres(items: Title[]): string[] {
  const set = new Set<string>();
  for (const item of items) for (const genre of item.genres) set.add(genre);
  return [...set].sort((a, b) => a.localeCompare(b));
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function httpUrl(value: unknown, label: string): string {
  if (typeof value !== "string" || value.length > 2000) {
    throw new Error(`${label} must be a URL.`);
  }
  if (value.startsWith("/")) return value;
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    throw new Error(`${label} must be an http(s) URL.`);
  }
  if (url.protocol !== "https:" && url.protocol !== "http:") {
    throw new Error(`${label} must be an http(s) URL.`);
  }
  return value;
}

function parseCaptions(value: unknown, label: string): Caption[] {
  if (value === undefined) return [];
  if (!Array.isArray(value)) throw new Error(`${label} must be an array.`);
  return value.map((entry, index) => {
    if (!isRecord(entry)) throw new Error(`${label}[${index}] is invalid.`);
    const lang = typeof entry.lang === "string" && entry.lang ? entry.lang : "en";
    const name = typeof entry.label === "string" && entry.label ? entry.label : lang;
    return { label: name, lang, src: httpUrl(entry.src, `${label}[${index}].src`) };
  });
}

function parseQualities(value: unknown, label: string): Stream[] {
  if (!Array.isArray(value) || value.length === 0) {
    throw new Error(`${label} needs at least one stream.`);
  }
  const streams = value.map((entry, index) => {
    if (!isRecord(entry)) throw new Error(`${label}[${index}] is invalid.`);
    const name = typeof entry.label === "string" && entry.label ? entry.label : `Source ${index + 1}`;
    const height = typeof entry.height === "number" ? entry.height : undefined;
    return { label: name, height, src: httpUrl(entry.src, `${label}[${index}].src`) };
  });
  return sortQualities(streams);
}

function parseEpisode(value: unknown, index: number): Episode {
  if (!isRecord(value)) throw new Error(`Episode ${index + 1} is invalid.`);
  const number = typeof value.number === "number" ? value.number : index + 1;
  const title = typeof value.title === "string" ? value.title.trim() : "";
  if (!title) throw new Error(`Episode ${number} needs a title.`);
  const id = typeof value.id === "string" && value.id ? value.id : `e-${number}`;
  return {
    id,
    number,
    title,
    synopsis: typeof value.synopsis === "string" ? value.synopsis : "",
    runtime: typeof value.runtime === "number" ? value.runtime : undefined,
    still: value.still === undefined ? undefined : httpUrl(value.still, `Episode ${number} still`),
    captions: parseCaptions(value.captions, `Episode ${number} captions`),
    qualities: parseQualities(value.qualities, `Episode ${number} qualities`),
  };
}

function parseTitle(value: unknown, index: number): Title {
  if (!isRecord(value)) throw new Error(`Title ${index + 1} is invalid.`);
  const title = typeof value.title === "string" ? value.title.trim() : "";
  if (!title) throw new Error(`Title ${index + 1} needs a title.`);
  const type = value.type === "series" ? "series" : value.type === "movie" ? "movie" : null;
  if (!type) throw new Error(`${title} must set type to "movie" or "series".`);
  const id = typeof value.id === "string" && value.id ? value.id : `title-${index + 1}`;
  const year = typeof value.year === "number" ? value.year : 0;
  const rating = typeof value.rating === "number" ? value.rating : 0;
  if (rating < 0 || rating > 10) throw new Error(`${title} rating must be from 0 to 10.`);
  const genres = Array.isArray(value.genres)
    ? value.genres.filter((genre): genre is string => typeof genre === "string")
    : [];
  const seasons = Array.isArray(value.seasons)
    ? value.seasons.map((season, seasonIndex) => {
        if (!isRecord(season) || !Array.isArray(season.episodes)) {
          throw new Error(`${title} season ${seasonIndex + 1} needs episodes.`);
        }
        return {
          number: typeof season.number === "number" ? season.number : seasonIndex + 1,
          episodes: season.episodes.map((episode, episodeIndex) => parseEpisode(episode, episodeIndex)),
        };
      })
    : [];
  if (type === "series" && seasons.every((season) => season.episodes.length === 0)) {
    throw new Error(`${title} needs at least one episode.`);
  }
  const qualities = type === "movie" ? parseQualities(value.qualities, `${title} qualities`) : [];
  return {
    id,
    type,
    title,
    year,
    genres,
    rating,
    runtime: typeof value.runtime === "number" ? value.runtime : undefined,
    synopsis: typeof value.synopsis === "string" ? value.synopsis : "",
    poster: httpUrl(value.poster, `${title} poster`),
    backdrop: value.backdrop === undefined ? undefined : httpUrl(value.backdrop, `${title} backdrop`),
    captions: parseCaptions(value.captions, `${title} captions`),
    qualities,
    seasons,
  };
}

export function parseCatalog(input: unknown): Catalog {
  if (!isRecord(input)) throw new Error("Catalog must be a JSON object.");
  if (!Array.isArray(input.items)) throw new Error('Catalog needs an "items" array.');
  if (input.items.length === 0) throw new Error("Catalog has no titles.");
  if (input.items.length > 500) throw new Error("Catalog is limited to 500 titles.");
  const items = input.items.map((item, index) => parseTitle(item, index));
  const name = typeof input.name === "string" && input.name.trim() ? input.name.trim() : "Catalog";
  return { name, items };
}
