export type ProgressEntry = {
  seconds: number;
  duration: number;
  updated: number;
  titleId: string;
  episodeId?: string;
  label: string;
  detail: string;
};

const KEY = "rabbit-progress";
const VOLUME_KEY = "rabbit-volume";
export const CATALOG_URL_KEY = "rabbit-catalog-url";

function readMap(): Record<string, ProgressEntry> {
  if (typeof localStorage === "undefined") return {};
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== "object") return {};
    return parsed as Record<string, ProgressEntry>;
  } catch {
    return {};
  }
}

export function loadProgress(): Record<string, ProgressEntry> {
  return readMap();
}

export function saveProgress(key: string, entry: ProgressEntry): Record<string, ProgressEntry> {
  const next = { ...readMap(), [key]: entry };
  localStorage.setItem(KEY, JSON.stringify(next));
  return next;
}

export function continueList(map: Record<string, ProgressEntry>): ProgressEntry[] {
  return Object.values(map)
    .filter((entry) => entry.seconds > 8 && entry.duration > 0 && entry.seconds < entry.duration - 12)
    .sort((a, b) => b.updated - a.updated);
}

export function loadVolume(): number {
  if (typeof localStorage === "undefined") return 1;
  const raw = localStorage.getItem(VOLUME_KEY);
  const value = raw === null ? 1 : Number(raw);
  if (!Number.isFinite(value)) return 1;
  return Math.min(1, Math.max(0, value));
}

export function saveVolume(volume: number): void {
  localStorage.setItem(VOLUME_KEY, String(volume));
}
