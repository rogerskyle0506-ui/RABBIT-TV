//#region node_modules/.nitro/vite/services/ssr/assets/catalog-BT6qxlXo.js
var SAMPLE_CAPTION = [{
	label: "English",
	lang: "en",
	src: "/captions/en.vtt"
}];
var DEMO_CATALOG = {
	name: "Sample shelf",
	items: [
		{
			id: "big-buck-bunny",
			type: "movie",
			title: "Big Buck Bunny",
			year: 2008,
			genres: [
				"Animation",
				"Comedy",
				"Family"
			],
			rating: 8.2,
			runtime: 10,
			synopsis: "A gentle giant of a rabbit has had enough of three bullying rodents. Open film from the Blender Foundation, on the sample shelf so you can try the player before connecting your catalog.",
			poster: "/posters/bunny.jpg",
			backdrop: "/posters/bunny-wide.jpg",
			captions: SAMPLE_CAPTION,
			qualities: [
				{
					label: "1080p",
					height: 1080,
					src: "https://upload.wikimedia.org/wikipedia/commons/transcoded/c/c0/Big_Buck_Bunny_4K.webm/Big_Buck_Bunny_4K.webm.1080p.vp9.webm"
				},
				{
					label: "720p",
					height: 720,
					src: "https://archive.org/download/BigBuckBunny_124/Content/big_buck_bunny_720p_surround.mp4"
				},
				{
					label: "480p",
					height: 480,
					src: "https://upload.wikimedia.org/wikipedia/commons/transcoded/c/c0/Big_Buck_Bunny_4K.webm/Big_Buck_Bunny_4K.webm.480p.vp9.webm"
				},
				{
					label: "360p",
					height: 360,
					src: "https://upload.wikimedia.org/wikipedia/commons/transcoded/c/c0/Big_Buck_Bunny_4K.webm/Big_Buck_Bunny_4K.webm.360p.vp9.webm"
				}
			],
			seasons: []
		},
		{
			id: "sintel",
			type: "movie",
			title: "Sintel",
			year: 2010,
			genres: [
				"Fantasy",
				"Adventure",
				"Drama"
			],
			rating: 7.6,
			runtime: 15,
			synopsis: "A young woman follows the trail of a lost dragon through snow and steel. Open film from the Blender Foundation, included on the sample shelf.",
			poster: "/posters/sintel.jpg",
			backdrop: "/posters/sintel.jpg",
			captions: SAMPLE_CAPTION,
			qualities: [{
				label: "2K",
				height: 1080,
				src: "https://archive.org/download/Sintel/sintel-2048-stereo.mp4"
			}, {
				label: "512 kbps",
				height: 480,
				src: "https://archive.org/download/Sintel/sintel-2048-stereo_512kb.mp4"
			}],
			seasons: []
		},
		{
			id: "tears-of-steel",
			type: "movie",
			title: "Tears of Steel",
			year: 2012,
			genres: ["Sci-Fi", "Action"],
			rating: 7.1,
			runtime: 12,
			synopsis: "In a ruined city, a crew tries to pull a warrior back from the machines. Open film from the Blender Foundation, included on the sample shelf.",
			poster: "/posters/steel.jpg",
			backdrop: "/posters/steel.jpg",
			captions: SAMPLE_CAPTION,
			qualities: [{
				label: "1080p",
				height: 1080,
				src: "https://archive.org/download/Tears-of-Steel/tears_of_steel_1080p.mp4"
			}, {
				label: "720p",
				height: 720,
				src: "https://archive.org/download/Tears-of-Steel/tears_of_steel_720p.mp4"
			}],
			seasons: []
		},
		{
			id: "elephants-dream",
			type: "movie",
			title: "Elephants Dream",
			year: 2006,
			genres: ["Sci-Fi", "Experimental"],
			rating: 6.4,
			runtime: 11,
			synopsis: "Two people wander a living machine that may only exist in one of their heads. Open film from the Blender Foundation, included on the sample shelf.",
			poster: "/posters/dream.jpg",
			backdrop: "/posters/dream.jpg",
			captions: SAMPLE_CAPTION,
			qualities: [
				{
					label: "HD",
					height: 1080,
					src: "https://archive.org/download/ElephantsDream/ed_hd.mp4"
				},
				{
					label: "1024",
					height: 576,
					src: "https://archive.org/download/ElephantsDream/ed_1024.mp4"
				},
				{
					label: "512 kbps",
					height: 480,
					src: "https://archive.org/download/ElephantsDream/ed_1024_512kb.mp4"
				}
			],
			seasons: []
		},
		{
			id: "caminandes",
			type: "series",
			title: "Caminandes",
			year: 2013,
			genres: [
				"Animation",
				"Comedy",
				"Short"
			],
			rating: 7.8,
			synopsis: "A llama, a desert, and three short open films from the Blender Foundation. Pick an episode and it starts at the highest quality in the file.",
			poster: "/posters/reels.jpg",
			backdrop: "/posters/reels.jpg",
			captions: [],
			qualities: [],
			seasons: [{
				number: 1,
				episodes: [
					{
						id: "cam-1",
						number: 1,
						title: "Llama Drama",
						synopsis: "The first short. Open film from the Blender Foundation.",
						runtime: 2,
						still: "/stills/escape.jpg",
						captions: SAMPLE_CAPTION,
						qualities: [{
							label: "1080p",
							height: 1080,
							src: "https://archive.org/download/Caminandes1LlamaDrama/01_llama_drama_1080p.mp4"
						}]
					},
					{
						id: "cam-2",
						number: 2,
						title: "Gran Dillama",
						synopsis: "The second short. Open film from the Blender Foundation.",
						runtime: 3,
						still: "/stills/joyride.jpg",
						captions: SAMPLE_CAPTION,
						qualities: [{
							label: "1080p",
							height: 1080,
							src: "https://archive.org/download/Caminandes2GranDillama/02_gran_dillama_1080p.mp4"
						}]
					},
					{
						id: "cam-3",
						number: 3,
						title: "Llamigos",
						synopsis: "The third short. Open film from the Blender Foundation.",
						runtime: 3,
						still: "/stills/blaze.jpg",
						captions: SAMPLE_CAPTION,
						qualities: [{
							label: "1080p",
							height: 1080,
							src: "https://archive.org/download/CaminandesLlamigos/Caminandes_%20Llamigos-1080p.mp4"
						}]
					}
				]
			}]
		}
	]
};
function sortQualities(qualities) {
	return [...qualities].sort((a, b) => qualityRank(b) - qualityRank(a));
}
function qualityRank(stream) {
	if (typeof stream.height === "number") return stream.height;
	const match = stream.label.match(/(\d{3,4})/);
	return match ? Number(match[1]) : 0;
}
function progressKey(titleId, episodeId) {
	return episodeId ? `${titleId}:${episodeId}` : titleId;
}
function findTitle(catalog, id) {
	return catalog.items.find((item) => item.id === id);
}
function titlesMatching(items, query) {
	const keyword = query.keyword.trim().toLowerCase();
	const year = query.year.trim();
	return items.filter((item) => {
		if (query.genre && !item.genres.some((genre) => genre.toLowerCase() === query.genre.toLowerCase())) return false;
		if (year && String(item.year) !== year) return false;
		if (item.rating < query.minRating) return false;
		if (!keyword) return true;
		const episodeText = item.seasons.flatMap((season) => season.episodes.map((episode) => `${episode.title} ${episode.synopsis}`)).join(" ");
		return `${item.title} ${item.synopsis} ${item.genres.join(" ")} ${episodeText}`.toLowerCase().includes(keyword);
	});
}
function allGenres(items) {
	const set = /* @__PURE__ */ new Set();
	for (const item of items) for (const genre of item.genres) set.add(genre);
	return [...set].sort((a, b) => a.localeCompare(b));
}
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function httpUrl(value, label) {
	if (typeof value !== "string" || value.length > 2e3) throw new Error(`${label} must be a URL.`);
	if (value.startsWith("/")) return value;
	let url;
	try {
		url = new URL(value);
	} catch {
		throw new Error(`${label} must be an http(s) URL.`);
	}
	if (url.protocol !== "https:" && url.protocol !== "http:") throw new Error(`${label} must be an http(s) URL.`);
	return value;
}
function parseCaptions(value, label) {
	if (value === void 0) return [];
	if (!Array.isArray(value)) throw new Error(`${label} must be an array.`);
	return value.map((entry, index) => {
		if (!isRecord(entry)) throw new Error(`${label}[${index}] is invalid.`);
		const lang = typeof entry.lang === "string" && entry.lang ? entry.lang : "en";
		return {
			label: typeof entry.label === "string" && entry.label ? entry.label : lang,
			lang,
			src: httpUrl(entry.src, `${label}[${index}].src`)
		};
	});
}
function parseQualities(value, label) {
	if (!Array.isArray(value) || value.length === 0) throw new Error(`${label} needs at least one stream.`);
	return sortQualities(value.map((entry, index) => {
		if (!isRecord(entry)) throw new Error(`${label}[${index}] is invalid.`);
		return {
			label: typeof entry.label === "string" && entry.label ? entry.label : `Source ${index + 1}`,
			height: typeof entry.height === "number" ? entry.height : void 0,
			src: httpUrl(entry.src, `${label}[${index}].src`)
		};
	}));
}
function parseEpisode(value, index) {
	if (!isRecord(value)) throw new Error(`Episode ${index + 1} is invalid.`);
	const number = typeof value.number === "number" ? value.number : index + 1;
	const title = typeof value.title === "string" ? value.title.trim() : "";
	if (!title) throw new Error(`Episode ${number} needs a title.`);
	return {
		id: typeof value.id === "string" && value.id ? value.id : `e-${number}`,
		number,
		title,
		synopsis: typeof value.synopsis === "string" ? value.synopsis : "",
		runtime: typeof value.runtime === "number" ? value.runtime : void 0,
		still: value.still === void 0 ? void 0 : httpUrl(value.still, `Episode ${number} still`),
		captions: parseCaptions(value.captions, `Episode ${number} captions`),
		qualities: parseQualities(value.qualities, `Episode ${number} qualities`)
	};
}
function parseTitle(value, index) {
	if (!isRecord(value)) throw new Error(`Title ${index + 1} is invalid.`);
	const title = typeof value.title === "string" ? value.title.trim() : "";
	if (!title) throw new Error(`Title ${index + 1} needs a title.`);
	const type = value.type === "series" ? "series" : value.type === "movie" ? "movie" : null;
	if (!type) throw new Error(`${title} must set type to "movie" or "series".`);
	const id = typeof value.id === "string" && value.id ? value.id : `title-${index + 1}`;
	const year = typeof value.year === "number" ? value.year : 0;
	const rating = typeof value.rating === "number" ? value.rating : 0;
	if (rating < 0 || rating > 10) throw new Error(`${title} rating must be from 0 to 10.`);
	const genres = Array.isArray(value.genres) ? value.genres.filter((genre) => typeof genre === "string") : [];
	const seasons = Array.isArray(value.seasons) ? value.seasons.map((season, seasonIndex) => {
		if (!isRecord(season) || !Array.isArray(season.episodes)) throw new Error(`${title} season ${seasonIndex + 1} needs episodes.`);
		return {
			number: typeof season.number === "number" ? season.number : seasonIndex + 1,
			episodes: season.episodes.map((episode, episodeIndex) => parseEpisode(episode, episodeIndex))
		};
	}) : [];
	if (type === "series" && seasons.every((season) => season.episodes.length === 0)) throw new Error(`${title} needs at least one episode.`);
	const qualities = type === "movie" ? parseQualities(value.qualities, `${title} qualities`) : [];
	return {
		id,
		type,
		title,
		year,
		genres,
		rating,
		runtime: typeof value.runtime === "number" ? value.runtime : void 0,
		synopsis: typeof value.synopsis === "string" ? value.synopsis : "",
		poster: httpUrl(value.poster, `${title} poster`),
		backdrop: value.backdrop === void 0 ? void 0 : httpUrl(value.backdrop, `${title} backdrop`),
		captions: parseCaptions(value.captions, `${title} captions`),
		qualities,
		seasons
	};
}
function parseCatalog(input) {
	if (!isRecord(input)) throw new Error("Catalog must be a JSON object.");
	if (!Array.isArray(input.items)) throw new Error("Catalog needs an \"items\" array.");
	if (input.items.length === 0) throw new Error("Catalog has no titles.");
	if (input.items.length > 500) throw new Error("Catalog is limited to 500 titles.");
	const items = input.items.map((item, index) => parseTitle(item, index));
	return {
		name: typeof input.name === "string" && input.name.trim() ? input.name.trim() : "Catalog",
		items
	};
}
//#endregion
export { progressKey as a, parseCatalog as i, allGenres as n, sortQualities as o, findTitle as r, titlesMatching as s, DEMO_CATALOG as t };
