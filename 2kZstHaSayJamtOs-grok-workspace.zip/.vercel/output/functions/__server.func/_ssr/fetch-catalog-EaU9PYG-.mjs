import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { i as parseCatalog } from "./catalog-BT6qxlXo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fetch-catalog-EaU9PYG-.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var MAX_BYTES = 15e5;
function isBlockedHost(hostname) {
	const host = hostname.toLowerCase().replace(/^\[|\]$/g, "");
	if (host === "localhost" || host.endsWith(".localhost") || host.endsWith(".local") || host === "metadata.google.internal" || host === "0.0.0.0") return true;
	if (host === "::1" || host.startsWith("fe80:") || host.startsWith("fc") || host.startsWith("fd")) return true;
	const match = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
	if (!match) return false;
	const parts = match.slice(1).map(Number);
	if (parts.some((part) => part > 255)) return true;
	const a = parts[0] ?? 0;
	const b = parts[1] ?? 0;
	if (a === 10 || a === 127 || a === 0) return true;
	if (a === 169 && b === 254) return true;
	if (a === 172 && b >= 16 && b <= 31) return true;
	if (a === 192 && b === 168) return true;
	if (a === 100 && b >= 64 && b <= 127) return true;
	return false;
}
var loadRemoteCatalog_createServerFn_handler = createServerRpc({
	id: "9d47fa16078d091b25cfc78c1136196efd22db3df3ea9374aa58c6664a3a6950",
	name: "loadRemoteCatalog",
	filename: "src/lib/fetch-catalog.ts"
}, (opts) => loadRemoteCatalog.__executeServer(opts));
var loadRemoteCatalog = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object" || !("url" in input)) throw new Error("Send a catalog URL.");
	const url = input.url;
	if (typeof url !== "string" || url.length < 8 || url.length > 2e3) throw new Error("Catalog URL is invalid.");
	return { url };
}).handler(loadRemoteCatalog_createServerFn_handler, async ({ data }) => {
	let parsed;
	try {
		parsed = new URL(data.url);
	} catch {
		throw new Error("Catalog URL is invalid.");
	}
	if (parsed.protocol !== "https:" && parsed.protocol !== "http:") throw new Error("Catalog URL must start with http:// or https://.");
	if (parsed.username || parsed.password) throw new Error("Catalog URL cannot include a password.");
	if (isBlockedHost(parsed.hostname)) throw new Error("That catalog address is not allowed.");
	const response = await fetch(parsed, {
		redirect: "manual",
		signal: AbortSignal.timeout(8e3),
		headers: { Accept: "application/json, text/plain;q=0.9,*/*;q=0.1" }
	});
	if (response.status >= 300 && response.status < 400) throw new Error("Catalog URL must point straight at the JSON file, with no redirect.");
	if (!response.ok) throw new Error(`Catalog server responded ${response.status}.`);
	if (Number(response.headers.get("content-length") || 0) > MAX_BYTES) throw new Error("Catalog file is too large.");
	const text = await response.text();
	if (text.length > MAX_BYTES) throw new Error("Catalog file is too large.");
	let json;
	try {
		json = JSON.parse(text);
	} catch {
		throw new Error("Catalog was not valid JSON.");
	}
	return parseCatalog(json);
});
//#endregion
export { loadRemoteCatalog_createServerFn_handler };
