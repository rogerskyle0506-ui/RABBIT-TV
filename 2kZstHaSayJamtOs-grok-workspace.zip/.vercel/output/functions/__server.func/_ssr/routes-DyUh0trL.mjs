import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as progressKey, n as allGenres, o as sortQualities, r as findTitle, s as titlesMatching, t as DEMO_CATALOG } from "./catalog-BT6qxlXo.mjs";
import { c as Play, d as House, f as Gauge, i as Tv, l as Pause, m as Captions, n as VolumeX, o as Settings, p as Clapperboard, r as Volume2, s as Search, t as X, u as Maximize } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DyUh0trL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var loadRemoteCatalog = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input !== "object" || !("url" in input)) throw new Error("Send a catalog URL.");
	const url = input.url;
	if (typeof url !== "string" || url.length < 8 || url.length > 2e3) throw new Error("Catalog URL is invalid.");
	return { url };
}).handler(createSsrRpc("9d47fa16078d091b25cfc78c1136196efd22db3df3ea9374aa58c6664a3a6950"));
var KEY = "rabbit-progress";
var VOLUME_KEY = "rabbit-volume";
var CATALOG_URL_KEY = "rabbit-catalog-url";
function readMap() {
	if (typeof localStorage === "undefined") return {};
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return {};
		const parsed = JSON.parse(raw);
		if (!parsed || typeof parsed !== "object") return {};
		return parsed;
	} catch {
		return {};
	}
}
function loadProgress() {
	return readMap();
}
function saveProgress(key, entry) {
	const next = {
		...readMap(),
		[key]: entry
	};
	localStorage.setItem(KEY, JSON.stringify(next));
	return next;
}
function continueList(map) {
	return Object.values(map).filter((entry) => entry.seconds > 8 && entry.duration > 0 && entry.seconds < entry.duration - 12).sort((a, b) => b.updated - a.updated);
}
function loadVolume() {
	if (typeof localStorage === "undefined") return 1;
	const raw = localStorage.getItem(VOLUME_KEY);
	const value = raw === null ? 1 : Number(raw);
	if (!Number.isFinite(value)) return 1;
	return Math.min(1, Math.max(0, value));
}
function saveVolume(volume) {
	localStorage.setItem(VOLUME_KEY, String(volume));
}
function clock(seconds) {
	if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
	const whole = Math.floor(seconds);
	const hours = Math.floor(whole / 3600);
	const minutes = Math.floor(whole % 3600 / 60);
	const remain = whole % 60;
	const sec = String(remain).padStart(2, "0");
	if (hours > 0) return `${hours}:${String(minutes).padStart(2, "0")}:${sec}`;
	return `${minutes}:${sec}`;
}
function Player({ playback, volume, onVolume, onProgress, onClose, onNext }) {
	const stageRef = (0, import_react.useRef)(null);
	const videoRef = (0, import_react.useRef)(null);
	const savedAt = (0, import_react.useRef)(null);
	const lastReport = (0, import_react.useRef)(0);
	const [qualityIndex, setQualityIndex] = (0, import_react.useState)(0);
	const [captionIndex, setCaptionIndex] = (0, import_react.useState)(-1);
	const [menu, setMenu] = (0, import_react.useState)(null);
	const [time, setTime] = (0, import_react.useState)(playback.startAt);
	const [duration, setDuration] = (0, import_react.useState)(0);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [failed, setFailed] = (0, import_react.useState)(false);
	const [hot, setHot] = (0, import_react.useState)(true);
	const [fs, setFs] = (0, import_react.useState)(false);
	const hideTimer = (0, import_react.useRef)(0);
	const stream = playback.qualities[qualityIndex] ?? playback.qualities[0];
	(0, import_react.useEffect)(() => {
		setQualityIndex(0);
		setCaptionIndex(-1);
		setReady(false);
		setFailed(false);
		setTime(playback.startAt);
		setMenu(null);
	}, [playback.key, playback.startAt]);
	(0, import_react.useEffect)(() => {
		const node = stageRef.current;
		node?.focus();
		(node?.requestFullscreen?.())?.catch(() => void 0);
		const onFs = () => setFs(document.fullscreenElement === node);
		document.addEventListener("fullscreenchange", onFs);
		return () => document.removeEventListener("fullscreenchange", onFs);
	}, [playback.key]);
	(0, import_react.useEffect)(() => {
		const video = videoRef.current;
		if (!video) return;
		video.volume = volume;
		video.muted = volume === 0;
	}, [volume, stream?.src]);
	function applyCaptions() {
		const video = videoRef.current;
		if (!video) return;
		for (let index = 0; index < video.textTracks.length; index += 1) video.textTracks[index].mode = index === captionIndex ? "showing" : "disabled";
	}
	(0, import_react.useEffect)(() => {
		applyCaptions();
	}, [captionIndex, stream?.src]);
	function poke() {
		setHot(true);
		window.clearTimeout(hideTimer.current);
		hideTimer.current = window.setTimeout(() => {
			if (videoRef.current && !videoRef.current.paused) setHot(false);
		}, 2800);
	}
	function toggle() {
		const video = videoRef.current;
		if (!video) return;
		if (video.paused) video.play();
		else video.pause();
		poke();
	}
	function chooseQuality(index) {
		const video = videoRef.current;
		savedAt.current = video?.currentTime ?? time;
		setQualityIndex(index);
		setReady(false);
		setFailed(false);
		setMenu(null);
		poke();
	}
	function onLoaded() {
		const video = videoRef.current;
		if (!video) return;
		setDuration(video.duration || 0);
		const resume = savedAt.current ?? playback.startAt;
		if (resume > 1 && Math.abs(video.currentTime - resume) > 1) video.currentTime = resume;
		savedAt.current = null;
		applyCaptions();
		setReady(true);
		video.play().catch(() => setPlaying(false));
	}
	async function toggleFullscreen() {
		const node = stageRef.current;
		if (!node) return;
		if (document.fullscreenElement) await document.exitFullscreen();
		else await node.requestFullscreen();
	}
	function onKeyDown(event) {
		const video = videoRef.current;
		if (!video) return;
		if (event.key === " " || event.key === "k") {
			event.preventDefault();
			toggle();
		} else if (event.key === "ArrowRight") video.currentTime = Math.min(video.duration || 0, video.currentTime + 10);
		else if (event.key === "ArrowLeft") video.currentTime = Math.max(0, video.currentTime - 10);
		else if (event.key === "f") toggleFullscreen();
		else if (event.key === "m") onVolume(volume === 0 ? 1 : 0);
		else if (event.key === "Escape" && !document.fullscreenElement) onClose();
		poke();
	}
	if (!stream) return null;
	const showChrome = hot || !playing || menu !== null || failed;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: stageRef,
		tabIndex: 0,
		onKeyDown,
		onPointerMove: poke,
		onPointerDown: poke,
		className: "fixed inset-0 z-50 flex flex-col bg-bg text-fg outline-none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref: videoRef,
				className: "h-full w-full bg-bg object-contain",
				poster: playback.poster,
				playsInline: true,
				onLoadedMetadata: onLoaded,
				onPlay: () => setPlaying(true),
				onPause: () => {
					setPlaying(false);
					setHot(true);
					const video = videoRef.current;
					if (video) onProgress(video.currentTime, video.duration || 0);
				},
				onTimeUpdate: () => {
					const video = videoRef.current;
					if (!video) return;
					setTime(video.currentTime);
					if (video.currentTime - lastReport.current > 5) {
						lastReport.current = video.currentTime;
						onProgress(video.currentTime, video.duration || 0);
					}
				},
				onEnded: () => {
					const video = videoRef.current;
					if (video) onProgress(video.currentTime, video.duration || 0);
					setPlaying(false);
					setHot(true);
				},
				onError: () => setFailed(true),
				onClick: toggle,
				children: playback.captions.map((caption) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("track", {
					kind: "subtitles",
					src: caption.src,
					srcLang: caption.lang,
					label: caption.label
				}, `${caption.lang}-${caption.src}`))
			}, stream.src),
			!ready && !failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 flex items-center justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "spin",
					role: "status",
					"aria-label": "Loading video"
				})
			}) : null,
			failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 flex flex-col items-center justify-center gap-3 px-6 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm text-base",
					children: "This stream did not load. Try another quality, or check the file URL in your catalog."
				}), playback.qualities.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap justify-center gap-2",
					children: playback.qualities.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "tap h-11 rounded-full bg-surface px-4 shadow-card transition-transform duration-150 ease-out active:scale-[0.96]",
						onClick: () => chooseQuality(index),
						children: item.label
					}, item.src))
				}) : null]
			}) : null,
			!playing && ready && !failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Play",
				onClick: toggle,
				className: "tap absolute top-1/2 left-1/2 flex size-16 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-accent text-fg transition-transform duration-150 ease-out active:scale-[0.96]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
					className: "size-7 translate-x-px",
					fill: "currentColor"
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `absolute inset-x-0 top-0 flex items-start justify-between gap-3 bg-gradient-to-b from-bg via-bg/80 to-transparent px-3 pt-3 pb-10 transition-opacity duration-200 ${showChrome ? "opacity-100" : "pointer-events-none opacity-0"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "tap flex size-11 items-center justify-center rounded-full bg-surface shadow-card transition-transform duration-150 ease-out active:scale-[0.96]",
					"aria-label": "Close player",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 pt-2 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-display text-lg tracking-wide",
						children: playback.title
					}), playback.subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm text-muted",
						children: playback.subtitle
					}) : null]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg via-bg/85 to-transparent px-3 pt-10 pb-3 transition-opacity duration-200 sm:px-5 ${showChrome ? "opacity-100" : "pointer-events-none opacity-0"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex h-11 items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: "Seek"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "slider",
							type: "range",
							min: 0,
							max: duration || 0,
							step: .1,
							value: Math.min(time, duration || 0),
							"aria-label": "Seek",
							onChange: (event) => {
								const next = Number(event.currentTarget.value);
								setTime(next);
								if (videoRef.current) videoRef.current.currentTime = next;
							}
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1 sm:gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: toggle,
								className: "tap flex size-11 items-center justify-center rounded-full transition-transform duration-150 ease-out active:scale-[0.96]",
								"aria-label": playing ? "Pause" : "Play",
								children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
									className: "size-5",
									fill: "currentColor"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
									className: "size-5 translate-x-px",
									fill: "currentColor"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "w-24 shrink-0 text-sm tabular-nums text-muted",
								children: [
									clock(time),
									" / ",
									clock(duration)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "ml-auto flex items-center gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-expanded": menu === "captions",
											"aria-label": "Captions",
											onClick: () => setMenu((current) => current === "captions" ? null : "captions"),
											className: "tap flex size-11 items-center justify-center rounded-full transition-transform duration-150 ease-out active:scale-[0.96]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Captions, { className: "size-5" })
										}), menu === "captions" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "absolute right-0 bottom-12 z-10 min-w-40 rounded-xl bg-raised p-1 shadow-card",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuButton, {
													active: captionIndex < 0,
													onClick: () => {
														setCaptionIndex(-1);
														setMenu(null);
													},
													children: "Off"
												}),
												playback.captions.map((caption, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuButton, {
													active: captionIndex === index,
													onClick: () => {
														setCaptionIndex(index);
														setMenu(null);
													},
													children: caption.label
												}, `${caption.lang}-${caption.src}`)),
												playback.captions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "px-3 py-2 text-sm text-muted",
													children: "No captions in this file."
												}) : null
											]
										}) : null]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											"aria-expanded": menu === "quality",
											"aria-label": "Stream quality",
											onClick: () => setMenu((current) => current === "quality" ? null : "quality"),
											className: "tap flex h-11 items-center gap-1 rounded-full px-2 text-sm transition-transform duration-150 ease-out active:scale-[0.96]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: stream.label })]
										}), menu === "quality" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "absolute right-0 bottom-12 z-10 min-w-36 rounded-xl bg-raised p-1 shadow-card",
											children: playback.qualities.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuButton, {
												active: index === qualityIndex,
												onClick: () => chooseQuality(index),
												children: index === 0 ? `${item.label} · max` : item.label
											}, item.src))
										}) : null]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "hidden h-11 w-28 items-center gap-2 sm:flex",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "sr-only",
												children: "Volume"
											}),
											volume === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5 shrink-0" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5 shrink-0" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												className: "slider",
												type: "range",
												min: 0,
												max: 1,
												step: .01,
												value: volume,
												"aria-label": "Volume",
												onChange: (event) => onVolume(Number(event.currentTarget.value))
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => void toggleFullscreen(),
										className: "tap flex size-11 items-center justify-center rounded-full transition-transform duration-150 ease-out active:scale-[0.96]",
										"aria-label": fs ? "Exit full screen" : "Full screen",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize, { className: "size-5" })
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-1 flex h-11 items-center gap-3 sm:hidden",
						children: [
							volume === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5 shrink-0" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5 shrink-0" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: "Volume"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "slider",
								type: "range",
								min: 0,
								max: 1,
								step: .01,
								value: volume,
								"aria-label": "Volume",
								onChange: (event) => onVolume(Number(event.currentTarget.value))
							})
						]
					}),
					onNext ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex justify-end pb-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onNext.start,
							className: "tap h-11 rounded-full bg-surface px-4 text-sm shadow-card transition-transform duration-150 ease-out active:scale-[0.96]",
							children: ["Next · ", onNext.label]
						})
					}) : null
				]
			})
		]
	});
}
function MenuButton({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: `flex h-11 w-full items-center rounded-lg px-3 text-left text-sm ${active ? "bg-surface text-fg" : "text-muted"}`,
		children
	});
}
var TABS = [
	{
		id: "home",
		label: "Home",
		icon: House
	},
	{
		id: "movies",
		label: "Movies",
		icon: Clapperboard
	},
	{
		id: "series",
		label: "Series",
		icon: Tv
	},
	{
		id: "search",
		label: "Search",
		icon: Search
	}
];
function ratingLabel(value) {
	return value.toFixed(1);
}
function App() {
	const [tab, setTab] = (0, import_react.useState)("home");
	const [catalog, setCatalog] = (0, import_react.useState)(DEMO_CATALOG);
	const [source, setSource] = (0, import_react.useState)("sample");
	const [catalogError, setCatalogError] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [settingsOpen, setSettingsOpen] = (0, import_react.useState)(false);
	const [draftUrl, setDraftUrl] = (0, import_react.useState)("");
	const [selectedId, setSelectedId] = (0, import_react.useState)(null);
	const [playback, setPlayback] = (0, import_react.useState)(null);
	const [progress, setProgress] = (0, import_react.useState)({});
	const [volume, setVolume] = (0, import_react.useState)(1);
	const [keyword, setKeyword] = (0, import_react.useState)("");
	const [genre, setGenre] = (0, import_react.useState)("");
	const [year, setYear] = (0, import_react.useState)("");
	const [minRating, setMinRating] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		setProgress(loadProgress());
		setVolume(loadVolume());
		const saved = localStorage.getItem(CATALOG_URL_KEY);
		if (saved) {
			setDraftUrl(saved);
			connect(saved);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		if (selectedId && !findTitle(catalog, selectedId)) setSelectedId(null);
	}, [catalog, selectedId]);
	async function connect(url) {
		setLoading(true);
		setCatalogError(null);
		try {
			const next = await loadRemoteCatalog({ data: { url } });
			setCatalog(next);
			setSource("remote");
			localStorage.setItem(CATALOG_URL_KEY, url);
			setDraftUrl(url);
			setSettingsOpen(false);
		} catch (error) {
			setCatalog(DEMO_CATALOG);
			setSource("sample");
			setCatalogError(error instanceof Error ? error.message : "Could not load that catalog.");
		} finally {
			setLoading(false);
		}
	}
	function useSample() {
		localStorage.removeItem(CATALOG_URL_KEY);
		setCatalog(DEMO_CATALOG);
		setSource("sample");
		setCatalogError(null);
		setDraftUrl("");
		setSettingsOpen(false);
	}
	function onVolume(next) {
		setVolume(next);
		saveVolume(next);
	}
	const selected = selectedId ? findTitle(catalog, selectedId) : void 0;
	const movies = catalog.items.filter((item) => item.type === "movie");
	const series = catalog.items.filter((item) => item.type === "series");
	const featured = movies[0] ?? catalog.items[0];
	const genres = allGenres(catalog.items);
	const results = titlesMatching(catalog.items, {
		keyword,
		genre,
		year,
		minRating
	});
	const resume = continueList(progress);
	function openTitle(id) {
		setSelectedId(id);
		setPlayback(null);
	}
	function playTitle(title, episode, startAt) {
		const qualities = sortQualities(episode ? episode.qualities : title.qualities);
		if (qualities.length === 0) return;
		const key = progressKey(title.id, episode?.id);
		const stored = progress[key];
		const at = startAt ?? (stored && stored.seconds > 8 ? stored.seconds : 0);
		setPlayback({
			key,
			titleId: title.id,
			episodeId: episode?.id,
			title: title.title,
			subtitle: episode ? `Season ${title.seasons.find((season) => season.episodes.some((item) => item.id === episode.id))?.number ?? 1} · E${episode.number} · ${episode.title}` : void 0,
			poster: episode?.still ?? title.backdrop ?? title.poster,
			qualities,
			captions: episode ? episode.captions : title.captions,
			startAt: at
		});
	}
	function nextEpisode(current) {
		if (!current.episodeId) return void 0;
		const title = findTitle(catalog, current.titleId);
		if (!title) return void 0;
		const flat = title.seasons.flatMap((season) => season.episodes);
		const upcoming = flat[flat.findIndex((episode) => episode.id === current.episodeId) + 1];
		if (!upcoming) return void 0;
		return {
			label: upcoming.title,
			start: () => playTitle(title, upcoming, 0)
		};
	}
	function recordProgress(seconds, duration) {
		if (!playback || !duration) return;
		const title = findTitle(catalog, playback.titleId);
		const entry = {
			seconds,
			duration,
			updated: Date.now(),
			titleId: playback.titleId,
			episodeId: playback.episodeId,
			label: title?.title ?? playback.title,
			detail: playback.subtitle ?? (title ? String(title.year) : "")
		};
		setProgress(saveProgress(playback.key, entry));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh overflow-x-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-line bg-bg/95 px-4 backdrop-blur-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/favicon.svg",
						alt: "",
						className: "size-9 rounded-lg"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 leading-none",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg tracking-widest",
							children: "RABBIT"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-muted",
							children: "PRODUCTIONS"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ml-auto hidden truncate text-sm text-muted sm:block",
						children: source === "remote" ? catalog.name : "Sample shelf"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setSettingsOpen(true),
						className: "tap flex size-11 items-center justify-center rounded-full transition-transform duration-150 ease-out active:scale-[0.96]",
						"aria-label": "Catalog settings",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-5" })
					})
				]
			}),
			catalogError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mx-4 mt-3 rounded-xl bg-surface px-4 py-3 text-sm text-fg shadow-card",
				children: [catalogError, " Showing the sample shelf instead."]
			}) : null,
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 pt-3 text-sm text-muted",
				children: "Loading catalog…"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "pb-24",
				children: selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
					title: selected,
					progress,
					onBack: () => setSelectedId(null),
					onPlay: (episode, at) => playTitle(selected, episode, at)
				}) : tab === "home" && featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeView, {
					featured,
					movies,
					series,
					resume,
					onOpen: openTitle,
					onPlay: playTitle
				}) : tab === "movies" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Grid, {
					heading: "Movies",
					items: movies,
					onOpen: openTitle
				}) : tab === "series" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Grid, {
					heading: "Series",
					items: series,
					onOpen: openTitle
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchView, {
					genres,
					keyword,
					genre,
					year,
					minRating,
					results,
					onKeyword: setKeyword,
					onGenre: setGenre,
					onYear: setYear,
					onRating: setMinRating,
					onOpen: openTitle
				})
			}),
			!playback ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "pb-safe fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg/95 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mx-auto flex max-w-lg",
					children: TABS.map((item) => {
						const active = !selected && tab === item.id;
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "flex-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-current": active ? "page" : void 0,
								onClick: () => {
									setSelectedId(null);
									setTab(item.id);
								},
								className: `relative flex h-16 w-full flex-col items-center justify-center gap-1 text-xs ${active ? "text-fg" : "text-muted"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-0 h-0.5 w-6 rounded-full bg-accent ${active ? "opacity-100" : "opacity-0"}` }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }),
									item.label
								]
							})
						}, item.id);
					})
				})
			}) : null,
			playback ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Player, {
				playback,
				volume,
				onVolume,
				onProgress: recordProgress,
				onClose: () => setPlayback(null),
				onNext: nextEpisode(playback)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatalogDialog, {
				open: settingsOpen,
				draft: draftUrl,
				loading,
				source,
				error: catalogError,
				onDraft: setDraftUrl,
				onClose: () => setSettingsOpen(false),
				onConnect: () => void connect(draftUrl.trim()),
				onSample: useSample
			})
		]
	});
}
function HomeView({ featured, movies, series, resume, onOpen, onPlay }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "hero relative",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: featured.backdrop ?? featured.poster,
					alt: "",
					className: "absolute inset-0 h-full w-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/50 to-bg/10" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 px-4 pb-5 sm:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-muted",
							children: "FEATURED"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-1 font-display text-4xl tracking-wide sm:text-6xl",
							children: featured.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xl text-sm text-fg/90 sm:text-base",
							children: featured.synopsis
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted",
							children: [
								featured.year,
								" · ",
								featured.genres.join(" · "),
								" · ",
								ratingLabel(featured.rating)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => featured.type === "movie" ? onPlay(featured) : onOpen(featured.id),
								className: "tap inline-flex h-12 items-center gap-2 rounded-full bg-accent px-5 text-fg transition-transform duration-150 ease-out active:scale-[0.96]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
									className: "size-5 translate-x-px",
									fill: "currentColor"
								}), featured.type === "movie" ? "Play" : "Episodes"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => onOpen(featured.id),
								className: "tap inline-flex h-12 items-center rounded-full bg-surface px-5 shadow-card transition-transform duration-150 ease-out active:scale-[0.96]",
								children: "Details"
							})]
						})
					]
				})
			]
		}),
		resume.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl tracking-wide",
				children: "Continue"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rail mt-3",
				children: resume.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onOpen(entry.titleId),
					className: "w-64 shrink-0 snap-start rounded-xl bg-surface p-3 text-left shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-display tracking-wide",
							children: entry.label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm text-muted",
							children: entry.detail
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 h-1 overflow-hidden rounded-full bg-line",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-accent",
								style: { width: `${Math.min(100, entry.seconds / entry.duration * 100)}%` }
							})
						})
					]
				}, progressKey(entry.titleId, entry.episodeId)))
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {
			title: "Movies",
			items: movies,
			onOpen
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {
			title: "Series",
			items: series,
			onOpen
		})
	] });
}
function Rail({ title, items, onOpen }) {
	if (items.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-6 px-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-xl tracking-wide",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rail mt-3",
			children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
				item,
				onOpen
			}, item.id))
		})]
	});
}
function Tile({ item, onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => onOpen(item.id),
		className: "w-36 shrink-0 snap-start text-left sm:w-44",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: item.poster,
				alt: "",
				className: "aspect-[2/3] w-full rounded-xl object-cover shadow-card outline outline-1 -outline-offset-1 outline-fg/10 transition-shadow duration-150 hover:shadow-card-hover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 truncate font-display tracking-wide",
				children: item.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					item.year,
					" · ",
					ratingLabel(item.rating)
				]
			})
		]
	});
}
function Grid({ heading, items, onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "px-4 pt-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl tracking-wide",
			children: heading
		}), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-muted",
			children: "Nothing in this shelf yet. Connect a catalog from the settings mark."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6",
			children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
				item,
				onOpen
			}, item.id))
		})]
	});
}
function Detail({ title, progress, onBack, onPlay }) {
	const [seasonIndex, setSeasonIndex] = (0, import_react.useState)(0);
	const season = title.seasons[seasonIndex] ?? title.seasons[0];
	const first = season?.episodes[0];
	const movieProgress = progress[progressKey(title.id)];
	const resumeEpisode = season?.episodes.find((episode) => {
		const entry = progress[progressKey(title.id, episode.id)];
		return entry && entry.seconds > 8 && entry.seconds < entry.duration - 12;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-72 sm:h-96",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: title.backdrop ?? title.poster,
				alt: "",
				className: "absolute inset-0 h-full w-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/40 to-bg/20" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onBack,
				className: "tap absolute top-3 left-3 flex size-11 items-center justify-center rounded-full bg-surface shadow-card transition-transform duration-150 ease-out active:scale-[0.96]",
				"aria-label": "Back",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "-mt-16 px-4 sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl tracking-wide",
				children: title.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted",
				children: [
					title.year,
					title.runtime ? ` · ${title.runtime} min` : "",
					" · ",
					title.genres.join(" · "),
					" · ",
					ratingLabel(title.rating)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-base",
				children: title.synopsis
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: title.type === "movie" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onPlay(void 0, movieProgress && movieProgress.seconds > 8 ? movieProgress.seconds : 0),
					className: "tap inline-flex h-12 items-center gap-2 rounded-full bg-accent px-5 text-fg transition-transform duration-150 ease-out active:scale-[0.96]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
						className: "size-5 translate-x-px",
						fill: "currentColor"
					}), movieProgress && movieProgress.seconds > 8 ? "Resume" : "Play"]
				}) : first ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onPlay(resumeEpisode ?? first),
					className: "tap inline-flex h-12 items-center gap-2 rounded-full bg-accent px-5 text-fg transition-transform duration-150 ease-out active:scale-[0.96]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
						className: "size-5 translate-x-px",
						fill: "currentColor"
					}), resumeEpisode ? `Resume E${resumeEpisode.number}` : `Play E${first.number}`]
				}) : null
			}),
			title.type === "series" && title.seasons.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rail mt-6",
				children: title.seasons.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setSeasonIndex(index),
					className: `h-11 shrink-0 rounded-full px-4 text-sm ${index === seasonIndex ? "bg-accent text-fg" : "bg-surface text-muted"}`,
					children: ["Season ", item.number]
				}, item.number))
			}) : null,
			season ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 divide-y divide-line border-t border-line",
				children: season.episodes.map((episode) => {
					const entry = progress[progressKey(title.id, episode.id)];
					const ratio = entry && entry.duration ? Math.min(1, entry.seconds / entry.duration) : 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onPlay(episode, entry && entry.seconds > 8 ? entry.seconds : 0),
						className: "flex w-full gap-3 py-3 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: episode.still ?? title.poster,
							alt: "",
							className: "h-16 w-28 shrink-0 rounded-lg object-cover shadow-card"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block font-display tracking-wide",
									children: [
										episode.number,
										". ",
										episode.title
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-sm text-muted",
									children: episode.synopsis
								}),
								ratio > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-2 block h-1 overflow-hidden rounded-full bg-line",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block h-full bg-accent",
										style: { width: `${ratio * 100}%` }
									})
								}) : null
							]
						})]
					}) }, episode.id);
				})
			}) : null
		]
	})] });
}
function SearchView({ genres, keyword, genre, year, minRating, results, onKeyword, onGenre, onYear, onRating, onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "px-4 pt-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl tracking-wide",
				children: "Search"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted",
					children: "Keywords"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: keyword,
					onChange: (event) => onKeyword(event.target.value),
					placeholder: "Title, plot, episode",
					className: "mt-1 h-12 w-full rounded-xl bg-surface px-4 text-fg shadow-card outline-none placeholder:text-muted"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted",
					children: "Year"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					inputMode: "numeric",
					value: year,
					onChange: (event) => onYear(event.target.value.replace(/[^\d]/g, "").slice(0, 4)),
					placeholder: "Any",
					className: "mt-1 h-12 w-full rounded-xl bg-surface px-4 text-fg shadow-card outline-none placeholder:text-muted"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex justify-between text-sm text-muted",
					children: ["Minimum rating", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-fg",
						children: minRating.toFixed(1)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 flex h-12 items-center rounded-xl bg-surface px-4 shadow-card",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "slider",
						type: "range",
						min: 0,
						max: 10,
						step: .1,
						value: minRating,
						"aria-label": "Minimum rating",
						onChange: (event) => onRating(Number(event.target.value))
					})
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rail mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: genre === "",
					onClick: () => onGenre(""),
					children: "All genres"
				}), genres.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: genre === item,
					onClick: () => onGenre(item),
					children: item
				}, item))]
			}),
			results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-muted",
				children: "No titles match that filter."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6",
				children: results.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
					item,
					onOpen
				}, item.id))
			})
		]
	});
}
function FilterChip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: `h-11 shrink-0 snap-start rounded-full px-4 text-sm ${active ? "bg-accent text-fg" : "bg-surface text-muted shadow-card"}`,
		children
	});
}
function CatalogDialog({ open, draft, loading, source, error, onDraft, onClose, onConnect, onSample }) {
	const example = (0, import_react.useMemo)(() => `{
  "name": "My shelf",
  "items": [{
    "id": "film-1",
    "type": "movie",
    "title": "Title",
    "year": 2024,
    "genres": ["Drama"],
    "rating": 7.5,
    "poster": "https://your.server/poster.jpg",
    "qualities": [
      { "label": "1080p", "height": 1080, "src": "https://your.server/film-1080.mp4" },
      { "label": "720p", "height": 720, "src": "https://your.server/film-720.mp4" }
    ],
    "captions": [
      { "label": "English", "lang": "en", "src": "https://your.server/film.vtt" }
    ]
  }]
}`, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (next) => {
			if (!next) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-bg/80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "fixed inset-x-3 top-16 z-40 max-h-[80dvh] overflow-y-auto rounded-2xl bg-surface p-5 shadow-card sm:inset-x-auto sm:left-1/2 sm:w-[32rem] sm:-translate-x-1/2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "font-display text-2xl tracking-wide",
						children: "Your catalog"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
						className: "flex size-11 items-center justify-center rounded-full",
						"aria-label": "Close",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "mt-2 text-sm text-muted",
					children: "Point this at a JSON file on your server. Movies and episodes need direct video URLs. The highest quality plays first. A full example is at /catalog.example.json."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-sm text-muted",
					children: ["Catalog URL", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: draft,
						onChange: (event) => onDraft(event.target.value),
						placeholder: "https://your.server/catalog.json",
						className: "mt-1 h-12 w-full rounded-xl bg-bg px-4 text-fg shadow-card outline-none placeholder:text-muted"
					})]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-accent",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: source === "remote" ? "Connected to your server." : "Using the built-in sample shelf."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: loading || draft.trim().length < 8,
						onClick: onConnect,
						className: "tap h-11 rounded-full bg-accent px-5 text-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-50",
						children: loading ? "Connecting…" : "Connect"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onSample,
						className: "tap h-11 rounded-full bg-bg px-5 shadow-card transition-transform duration-150 ease-out active:scale-[0.96]",
						children: "Use sample shelf"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "mt-5 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "cursor-pointer text-muted",
						children: "Catalog shape"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-3 overflow-x-auto rounded-xl bg-bg p-3 text-xs leading-relaxed text-fg",
						children: example
					})]
				})
			]
		})] })
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(App, {});
}
//#endregion
export { Home as component };
