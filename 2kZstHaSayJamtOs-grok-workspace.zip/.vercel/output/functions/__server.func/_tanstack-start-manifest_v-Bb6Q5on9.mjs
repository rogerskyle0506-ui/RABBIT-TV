//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bb6Q5on9.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DqQPrlfy.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DqQPrlfy.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BLj3w3Ov.js"]
	}
} });
//#endregion
export { tsrStartManifest };
